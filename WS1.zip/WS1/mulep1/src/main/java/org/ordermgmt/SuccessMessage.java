package org.ordermgmt;

/**
 * Sends a success message.
 * 
 * @author Derek
 */
public class SuccessMessage {

	/**
	 * Sends a success message.
	 * 
	 * @param input
	 * @return
	 */
	public String successMessage(Object input) {
		return "Success!";
	}
}